<?php require_once(dirname(__FILE__).DIRECTORY_SEPARATOR.'../required/connect.php'); 
header('location:login.php');
?>